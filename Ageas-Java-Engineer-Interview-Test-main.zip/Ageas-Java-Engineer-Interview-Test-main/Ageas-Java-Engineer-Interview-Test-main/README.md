Please download a copy of this requirements code repository, work on it locally and then upload to your own github account.
Please email grace.robson@ageas.co.uk when you have completed the exercise to confirm it is ready for review.
Failure to complete the exercise at least 24 hours prior to interview will mean the interview will not go ahead and cannot be reschedule.
Thank you for your understanding :)
